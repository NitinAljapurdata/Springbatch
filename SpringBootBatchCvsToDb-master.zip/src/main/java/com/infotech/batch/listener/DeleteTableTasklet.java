package com.infotech.batch.listener;

import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.infotech.batch.model.Person;

public class DeleteTableTasklet implements Tasklet {

	private final DataSource dataSource;
	private final JdbcTemplate jdbcTemplate;
	private static final Logger logger = LoggerFactory.getLogger(DeleteTableTasklet.class);
	@Autowired
	public DeleteTableTasklet(DataSource dataSource) {
		this.dataSource = dataSource;
		this.jdbcTemplate = new JdbcTemplate(this.dataSource);
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		logger.info("Going to delete Person table ");
		this.jdbcTemplate.execute("DELETE FROM PERSON");
		
		List<Person> queryForList = this.jdbcTemplate.queryForList("SELECT FIRST_NAME FROM PERSON", Person.class);
		if(queryForList.isEmpty())
		{
			logger.info("QueryForList size is zero");
		}else{
			logger.info("QueryForList size is NOTTTTTTTTTTT zero");
		}
			return RepeatStatus.FINISHED;
	}
}